<form method="get" id="searchform" action="<?php echo esc_url( home_url( '/' ) ); ?>">
<div>
<label for="s"><?php _e('Search for','appliance');?></label>
<input type="text" class="field" name="s" id="s" />
<input type="hidden" id="searchsubmit" value="Search" />
</div>
</form>

