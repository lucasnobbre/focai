<?php get_header(); ?>
<div id="maincontent">

<h1><?php _e('This page cannot be found','appliance')?></h1>

<p><?php _e('The page you are looking for does not exist.','appliance')?></p>

<p><a href="<?php echo site_url()?>"><?php _e('Click here to return to the homepage','appliance')?></a></p>


</div>

<?php get_footer(); ?>