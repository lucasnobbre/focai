Appliance is a clean and minimalist theme, ideal for blogs / magazines / portfolios.  Spacious, minimalist, clean, light and very fast to load.

The image shown for each post is the featured image (you can define this when editing each post) and if that image doesn't exist, then it will then show the post's main image instead.  For your information - the thumbnail is 214 pixels wide by 120 pixels in height.

Post titles are restricted to one line displayed in order to maintain a consistent appearance throughout the website.

Please note: When setting up widgets - you need to specify a title for each widget, in order for it to appear.  In particular for the Search Widget - this widget does not have a title by default - so you will need to specify this (i.e. type in a title for this widget such as "Search").

This theme is free for both personal and commercial use.

Emma

